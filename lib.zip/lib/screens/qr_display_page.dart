// lib/screens/qr_display_page.dart
// Hata Düzeltmesi: textTheme.caption yerine textTheme.bodySmall kullanıldı.
// Önceki print eklemeleri korunuyor.

import 'package:flutter/material.dart';
import 'package:qr_flutter/qr_flutter.dart'; // qr_flutter importu

class QRDisplayPage extends StatelessWidget {
  final String recordId; // Gelen veri (UID|VehicleID formatında olmalı)

  const QRDisplayPage({Key? key, required this.recordId}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // --- PRINT EKLEMESİ BAŞLANGICI ---
    print("--- QR Görüntüleme Sayfası (QRDisplayPage) ---");
    print("Sayfaya Gelen recordId: $recordId");
    // --- PRINT EKLEMESİ SONU ---

    bool isValidFormat = recordId.contains('|') && recordId.split('|').length == 2;
    if (!isValidFormat) {
       print("UYARI: QRDisplayPage'e gelen recordId beklenen formatta değil ('|' içermiyor veya parça sayısı 2 değil): $recordId");
    }

    return Scaffold(
      appBar: AppBar(title: const Text("Tutanak QR Kodu")),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              const Text(
                "Diğer sürücünün bu QR kodu okutmasını sağlayın.",
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 16)
              ),
              const SizedBox(height: 30),

              if (recordId.isNotEmpty && isValidFormat)
                QrImageView(
                  data: recordId,
                  version: QrVersions.auto,
                  size: 250.0,
                  gapless: false,
                  errorStateBuilder: (cxt, err) {
                    print("!!! QR Kodu Oluşturma Hatası: $err");
                    return Container(
                       width: 250, height: 250, alignment: Alignment.center, color: Colors.grey.shade200,
                       child: const Text( "Hata:\nQR Kodu oluşturulamadı.", textAlign: TextAlign.center, style: TextStyle(color: Colors.red), ),
                    );
                  },
                )
              else if (recordId.isEmpty)
                 Container(
                    width: 250, height: 250, alignment: Alignment.center, color: Colors.grey.shade200,
                    child: const Text( "Hata:\nQR Kodu oluşturmak için\nveri bulunamadı!", textAlign: TextAlign.center, style: TextStyle(color: Colors.red, fontWeight: FontWeight.bold), ),
                 )
              else
                 Container(
                    width: 250, height: 250, alignment: Alignment.center, color: Colors.grey.shade200,
                    child: Text( "Hata:\nQR Kodu için geçersiz\nveri formatı!\nBeklenen: UID|AraçID\nGelen: $recordId", textAlign: TextAlign.center, style: const TextStyle(color: Colors.red, fontWeight: FontWeight.bold), ),
                 ),

              const SizedBox(height: 20),
              // Görüntülenen veriyi küçük bir yazıyla gösterelim (debug için)
              Text(
                "Kodlanan Veri: $recordId",
                // DÜZELTME: caption yerine bodySmall kullanıldı
                style: Theme.of(context).textTheme.bodySmall?.copyWith(fontSize: 10),
                overflow: TextOverflow.ellipsis,
                maxLines: 2,
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
      ),
    );
  }
}