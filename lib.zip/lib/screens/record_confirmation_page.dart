// lib/screens/record_confirmation_page.dart
// BU DOSYAYA HATA AYIKLAMA İÇİN print() KOMUTLARI EKLENMİŞTİR

import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class RecordConfirmationPage extends StatefulWidget {
  final String qrData;           // Okunan ham veri: creatorUid|creatorVehicleId
  final String joinerVehicleId;  // Katılanın kendi seçtiği AraçID

  const RecordConfirmationPage({
    Key? key,
    required this.qrData,
    required this.joinerVehicleId,
  }) : super(key: key);

  @override
  _RecordConfirmationPageState createState() => _RecordConfirmationPageState();
}

class _RecordConfirmationPageState extends State<RecordConfirmationPage> {
  Future<Map<String, dynamic>>? _infoFuture;
  String? _errorMessage;

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  void _loadData() {
     setState(() {
       _infoFuture = _fetchAllInfo();
     });
  }

  Future<Map<String, dynamic>> _fetchAllInfo() async {
    // --- HATA AYIKLAMA PRINT KOMUTLARI BAŞLANGICI ---
    print('--- RecordConfirmationPage ---');
    print('Alınan QR Verisi: ${widget.qrData}');
    print('Katılanın Seçtiği Araç IDsi: ${widget.joinerVehicleId}');
    // --- HATA AYIKLAMA PRINT KOMUTLARI SONU ---

    final firestore = FirebaseFirestore.instance;
    final currentUser = FirebaseAuth.instance.currentUser;

    // 1) Katılan kullanıcıyı kontrol et (oturum açık mı?)
    if (currentUser == null) {
      print('HATA: Kullanıcı girişi yapılmamış!'); // Hata logu
      throw Exception('İşlem için kullanıcı girişi gerekli.');
    }
    final joinerUid = currentUser.uid;
     print('Katılan (Oturum Açan) Kullanıcı UID: $joinerUid'); // Katılan UID'sini yazdır

    // 2) QR verisini parse et
    final parts = widget.qrData.split('|');
    if (parts.length != 2 || parts[0].isEmpty || parts[1].isEmpty) {
       print('HATA: Geçersiz QR Verisi Formatı!'); // Hata logu
       throw Exception('Geçersiz QR verisi formatı: ${widget.qrData}');
    }
    final creatorUid = parts[0];
    final creatorVehicleId = parts[1];

    // --- HATA AYIKLAMA PRINT KOMUTLARI BAŞLANGICI ---
    print('>>> Firestore Sorgusu Başlıyor <<<');
    print('Aranacak Oluşturan UID: $creatorUid');
    print('Aranacak Oluşturan Araç ID: $creatorVehicleId');
    print('Aranacak Katılan UID: $joinerUid'); // Zaten yukarıda yazdırıldı ama burada tekrar olabilir.
    print('Aranacak Katılan Araç ID: ${widget.joinerVehicleId}');
    // --- HATA AYIKLAMA PRINT KOMUTLARI SONU ---


    // 3) Oluşturan kullanıcı verisini çek
    print('Adım 3: Oluşturan kullanıcı verisi çekiliyor (users/$creatorUid)...');
    final creatorDocRef = firestore.collection('users').doc(creatorUid);
    final creatorSnap = await creatorDocRef.get();
    if (!creatorSnap.exists || creatorSnap.data() == null) {
      print('HATA: Oluşturan kullanıcı bulunamadı!'); // Hata logu
      throw Exception('QR koduna sahip sürücü bilgisi bulunamadı (ID: $creatorUid).');
    }
    print('Adım 3 Başarılı: Oluşturan kullanıcı verisi bulundu.');
    final creatorData = creatorSnap.data()!;

    // 4) Oluşturanın araç verisini çek
    print('Adım 4: Oluşturanın araç verisi çekiliyor (users/$creatorUid/vehicles/$creatorVehicleId)...');
    final creatorVehicleDocRef = creatorDocRef.collection('vehicles').doc(creatorVehicleId);
    final creatorVehicleSnap = await creatorVehicleDocRef.get();
    if (!creatorVehicleSnap.exists || creatorVehicleSnap.data() == null) {
       print('HATA: Oluşturanın aracı bulunamadı!'); // Hata logu
       throw Exception('QR koduna sahip sürücünün aracı bulunamadı (Araç ID: $creatorVehicleId).');
    }
    print('Adım 4 Başarılı: Oluşturanın araç verisi bulundu.');
    final creatorVehicleData = creatorVehicleSnap.data()!;

    // 5) Katılan kullanıcı (zaten oturum açmış olan) verisini çek
    print('Adım 5: Katılan kullanıcı verisi çekiliyor (users/$joinerUid)...');
    final joinerDocRef = firestore.collection('users').doc(joinerUid);
    final joinerSnap = await joinerDocRef.get();
    if (!joinerSnap.exists || joinerSnap.data() == null) {
      print('HATA: Katılan kullanıcı bulunamadı!'); // Hata logu
      throw Exception('Kendi sürücü bilginiz bulunamadı (ID: $joinerUid).');
    }
    print('Adım 5 Başarılı: Katılan kullanıcı verisi bulundu.');
    final joinerData = joinerSnap.data()!;

    // 6) Katılanın seçtiği araç verisini çek
     print('Adım 6: Katılanın araç verisi çekiliyor (users/$joinerUid/vehicles/${widget.joinerVehicleId})...');
    final joinerVehicleDocRef = joinerDocRef.collection('vehicles').doc(widget.joinerVehicleId);
    final joinerVehicleSnap = await joinerVehicleDocRef.get();
    if (!joinerVehicleSnap.exists || joinerVehicleSnap.data() == null) {
      print('HATA: Katılanın aracı bulunamadı!'); // Hata logu
      throw Exception('Seçtiğiniz araç bulunamadı (Araç ID: ${widget.joinerVehicleId}).');
    }
    print('Adım 6 Başarılı: Katılanın araç verisi bulundu.');
    final joinerVehicleData = joinerVehicleSnap.data()!;

    print('>>> Firestore Sorgusu Başarıyla Tamamlandı <<<');

    return {
      'creatorData': creatorData,
      'creatorVehicleData': creatorVehicleData,
      'creatorVehicleId': creatorVehicleId,
      'joinerData': joinerData,
      'joinerVehicleData': joinerVehicleData,
      'joinerVehicleId': widget.joinerVehicleId,
    };
  }

  String _getString(Map<String, dynamic> data, String key, [String defaultValue = 'Bilgi Yok']) {
     return data[key]?.toString() ?? defaultValue;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Tutanak Bilgileri Onayı'),
      ),
      body: FutureBuilder<Map<String, dynamic>>(
        future: _infoFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          if (snapshot.hasError) {
            _errorMessage = snapshot.error.toString();
             // Hata mesajını ve sebebini konsola DAHA detaylı yazdır
             print("FutureBuilder HATA YAKALADI: $_errorMessage");
             // Eğer hata FirebaseException ise daha fazla detay yazdırabiliriz
             if (snapshot.error is FirebaseException) {
                FirebaseException e = snapshot.error as FirebaseException;
                print("Firebase Hata Kodu: ${e.code}");
                print("Firebase Hata Mesajı: ${e.message}");
             }
             return Center(
               child: Padding(
                 padding: const EdgeInsets.all(16.0),
                 child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(Icons.error_outline, color: Colors.red, size: 50),
                      const SizedBox(height: 10),
                      const Text(
                         'Bilgiler yüklenirken bir hata oluştu:',
                         textAlign: TextAlign.center,
                         style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 5),
                      // Ekranda gösterilen hata mesajı:
                      Text(
                        // Mesajı biraz daha kullanıcı dostu yapalım
                        _errorMessage!.replaceFirst("Exception: ", ""), // "Exception: " kısmını kaldır
                        textAlign: TextAlign.center,
                        style: const TextStyle(color: Colors.red),
                      ),
                      const SizedBox(height: 20),
                      ElevatedButton(
                        onPressed: () => Navigator.pop(context),
                        child: const Text('Geri Dön'),
                      ),
                       ElevatedButton(
                        onPressed: _loadData,
                        child: const Text('Tekrar Dene'),
                      ),
                    ],
                 ),
               ),
             );
          }

          if (snapshot.hasData) {
            final info = snapshot.data!;
            final creator = info['creatorData'] as Map<String, dynamic>;
            final cv = info['creatorVehicleData'] as Map<String, dynamic>;
            final joiner = info['joinerData'] as Map<String, dynamic>;
            final jv = info['joinerVehicleData'] as Map<String, dynamic>;

             // Verilerin başarıyla geldiğini konsola yazdıralım (opsiyonel)
             print("FutureBuilder: Veriler başarıyla yüklendi ve gösteriliyor.");

            return Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Card(
                     elevation: 2,
                     margin: const EdgeInsets.only(bottom: 16),
                     child: Padding(
                       padding: const EdgeInsets.all(16.0),
                       child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                             const Text('Diğer Sürücü (QR Sahibi):',
                                 style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                             const SizedBox(height: 8),
                             Text('Ad Soyad: ${_getString(creator, 'isim')} ${_getString(creator, 'soyisim')}'),
                             Text('Telefon: ${_getString(creator, 'telefon', 'Telefon Yok')}'),
                             const SizedBox(height: 8),
                             Text('Araç: ${_getString(cv, 'marka')} ${_getString(cv, 'seri')}'),
                             Text('Plaka: ${_getString(cv, 'plaka')}'),
                          ],
                       ),
                     ),
                  ),
                  Card(
                     elevation: 2,
                     margin: const EdgeInsets.only(bottom: 16),
                     child: Padding(
                       padding: const EdgeInsets.all(16.0),
                       child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                             const Text('Siz (QR Okutan):',
                                 style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                             const SizedBox(height: 8),
                             Text('Ad Soyad: ${_getString(joiner, 'isim')} ${_getString(joiner, 'soyisim')}'),
                             Text('Telefon: ${_getString(joiner, 'telefon', 'Telefon Yok')}'),
                             const SizedBox(height: 8),
                             Text('Seçili Araç: ${_getString(jv, 'marka')} ${_getString(jv, 'seri')}'),
                             Text('Plaka: ${_getString(jv, 'plaka')}'),
                          ],
                       ),
                     ),
                  ),
                  const Spacer(),
                  ElevatedButton(
                    onPressed: () {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text("Bilgiler onaylandı (kayıt işlemi eklenmedi).")),
                      );
                      Navigator.popUntil(context, (route) => route.isFirst);
                    },
                    style: ElevatedButton.styleFrom(
                        minimumSize: const Size(double.infinity, 50)),
                    child: const Text('Bilgileri Onayla ve Devam Et'),
                  ),
                   const SizedBox(height: 8),
                   OutlinedButton(
                     onPressed: () => Navigator.pop(context),
                     style: OutlinedButton.styleFrom(
                        minimumSize: const Size(double.infinity, 50),
                        side: BorderSide(color: Theme.of(context).colorScheme.primary),
                     ),
                     child: const Text('Vazgeç'),
                   ),
                ],
              ),
            );
          }
          return const Center(child: Text('Beklenmeyen bir durum oluştu.'));
        },
      ),
    );
  }
}